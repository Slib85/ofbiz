The SF-0801 has the ability to hold a 1/8" to 1/4" thick flash drive in the right pocket. If you would like to use this option please choose the template with FLASH in the name.
